package com.InnovXcel.joblisting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JoblistingApplicationTests {

	@Test
	void contextLoads() {
	}

}
